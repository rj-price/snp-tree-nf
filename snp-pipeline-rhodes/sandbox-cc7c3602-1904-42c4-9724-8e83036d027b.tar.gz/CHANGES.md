# Changes Log - SNP Annotation Removal

## Summary
Removed SNP annotation step from the pipeline as requested. The pipeline now goes directly from variant filtering to SNP matrix creation for phylogenetic analysis.

## Files Modified

### 1. `main.nf`
- **Removed**: `include { ANNOTATE_VARIANTS }` statement
- **Removed**: `ANNOTATE_VARIANTS` process call from workflow
- **Updated**: Pipeline flow now goes directly from `GATK_VARIANTFILTRATION` to `CREATE_SNP_MATRIX`
- **Updated**: Pipeline description updated to reflect 5 main steps instead of 6

**Before:**
```groovy
GATK_VARIANTFILTRATION() → ANNOTATE_VARIANTS() → CREATE_SNP_MATRIX()
```

**After:**
```groovy
GATK_VARIANTFILTRATION() → CREATE_SNP_MATRIX()
```

### 2. `modules/annotate_variants.nf`
- **Deleted**: Entire module file removed as it's no longer needed

### 3. `modules/create_snp_matrix.nf`
- **Updated**: Now handles compressed VCF files (`.vcf.gz`) directly from variant filtration
- **Added**: `gzip` import for handling compressed VCF files
- **Added**: File handle management with try/finally block for proper resource cleanup
- **Updated**: Sample name parsing to handle `.filtered.vcf.gz` file extensions

### 4. `nextflow.config`
- **Removed**: Container definition for `ANNOTATE_VARIANTS` process (Docker profile)
- **Removed**: Container definition for `ANNOTATE_VARIANTS` process (Singularity profile)

### 5. `README.md`
- **Updated**: Pipeline overview now lists 7 steps instead of 8
- **Removed**: References to "Variant Annotation" and "vcf-annotator"
- **Updated**: Output structure section removed `annotated/` directory
- **Updated**: Pipeline workflow diagram simplified to remove annotation step

### 6. `USAGE.md`
- **Removed**: Troubleshooting section for VCF-annotator

## Pipeline Flow (Updated)

```
FASTQ Files
    ↓
FastQC (Quality Control)
    ↓
BWA-MEM (Alignment)
    ↓
SAMtools (Sort & Index)
    ↓
GATK HaplotypeCaller (Variant Calling)
    ↓
GATK VariantFiltration (Filtering)
    ↓
Create SNP Matrix (Presence/Absence)
    ↓
RAxML (Phylogenetic Tree)
```

## Output Structure (Updated)

```
results/
├── fastqc/
├── alignments/
├── variants/
│   ├── raw/
│   └── filtered/          # Now feeds directly to phylogenetics
└── phylogenetics/
    ├── snp_matrix.phylip
    └── RAxML_*
```

## Testing Status

✅ **Linting**: All 9 remaining module files pass `nextflow lint` with no errors
✅ **Workflow**: Pipeline flow validated and correctly connected
✅ **Documentation**: All references to annotation removed from docs

## Impact

- **Simplified pipeline**: One less step to maintain and debug
- **Faster execution**: Removes annotation overhead
- **Direct workflow**: Filtered variants go straight to phylogenetic analysis
- **Maintained functionality**: SNP matrix creation and phylogenetic analysis unchanged

## Module Count

- **Before**: 10 modules
- **After**: 9 modules
- **Removed**: `annotate_variants.nf`

## No Breaking Changes

The pipeline still requires the same input files and produces the same phylogenetic outputs. The only difference is the removal of intermediate annotated VCF files.
